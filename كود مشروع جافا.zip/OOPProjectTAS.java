
package oopprojecttas;


import static oopprojecttas.Location.findLocation;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
import java.util.ArrayList;
public class OOPProjectTAS {
static Scanner input=new Scanner (System.in);
    public static void main(String[] args) {
         
       
        int choice;
        System.out.println("-----------Welcome to TAS system-----------");
        do{
        System.out.println("our services is:\n1-Log in\n2-The budget\n3-Flight booking\n4-Hootel booking\n5-Uber\n6-Resturant\n7-Shop\n8-Emergencey\n9-location\n10-exit");
        choice=input.nextInt();
        switch(choice){
            case 1:OOPProjectTAS app = new OOPProjectTAS();
        app.start();
        
            case 2:  calculateBudget(); break;
            case 3:distecket();  break;
            case 4:displayHootelBooking();break;
            case 5: Trip(); break;
            case 6:System.out.print("Enter the city for restaurant suggestions: ");
                    input.nextLine();  //
                    String city = input.nextLine();
                suggestRestaurants(city);   break;
            case 7:  shopsInfoDis(); break;
            case 8: emergencyDis();  break;
            case 9: test(); break;
         case 10: System.out.println("thank you , goodbye <3 ");
             break;
        }}while(choice!=10);
    }


   


    public void start() {
        executeProgramLogic();
    }

    private void executeProgramLogic() {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.print("Enter the username: ");
            String username = scanner.nextLine();

            System.out.print("Enter the password: ");
            String password = scanner.nextLine();

            System.out.print("Enter day of birth: ");
            int day = scanner.nextInt();

            System.out.print("Enter month of birth: ");
            int month = scanner.nextInt();

            System.out.print("Enter year of birth: ");
            int year = scanner.nextInt();
            scanner.nextLine();

            TravelInfo user = new TravelInfo(username, password, day, month, year);

            System.out.print("To log in, enter your username: ");
            String enteredUsername = scanner.nextLine();

            System.out.print("Enter your password: ");
            String enteredPassword = scanner.nextLine();

            if (user.login(enteredUsername, enteredPassword)) {
                System.out.println("Login successful!");
                user.collectTravelInfo(scanner);
                System.out.println("\nUser Information:");
                System.out.println(user.displayInfo());
            } else {
                System.out.println("Invalid username or password.");
            }
        }
    }


    //ميثود كلاس الميزانية لاثير
   public static void calculateBudget() {
   Scanner in=new Scanner(System.in);
    HotelBooking hotelBooking = new HotelBooking();
     
//    Uber uber = new Uber();ً
    Uber uber=new Uber();
    flightBooking flightBooking = new flightBooking();  
    in.nextInt();
    
    Budget budgetCalculator = new Budget(hotelBooking, uber, flightBooking);
    budgetCalculator.calculateTotalCost();  
}
                                                                                      

    
    
        
    
    //ميثود ياسمين لكلاس flightBooking
    public static void distecket(){
        ArrayList<flightBooking> tickets = new ArrayList<>();
       
        tickets.add(new flightBooking("dammam","macca","king fahad airport","jeddah airport","2:30pm","6:30pm", 45 , 1000.0));
        tickets.add(new flightBooking("riyadh","macca","khalid king airport","jeddah airport","10:00 am","1:00pm",30 , 900.0));
        tickets.add(new flightBooking("khobar","Al Ula ","king fahad airport","Al Ula airport","4:30pm","7:30pm", 40 , 1500.0));
        tickets.add(new flightBooking("tabuk ","Al Ula","sultan prince airport","Al Ula airport","7:30pm","10:30pm", 50 , 1070.0));
        tickets.add(new flightBooking("jeddah","Abha ","jeddah airport","Abha airport","10:00am","2:00pm", 45 , 1000.0));
        tickets.add(new flightBooking("dammam","Abha","king fahad airport","Abha airport","2:30pm","6:30pm", 60 , 1000.0));
        tickets.add(new flightBooking("khubar","al riyadh","king fahad airport","khalid king airport","2:30pm","6:30pm", 45 , 950.0));
        tickets.add(new flightBooking("jazan","Al riyadh","abdullah king airport","khalid king airport","2:30pm","6:30pm", 45 , 1000.0));
        tickets.add(new flightBooking("al riyadh","khubar","khalid king airport","fahad king airport","2:30pm","6:30pm", 45 , 1000.0));
        tickets.add(new flightBooking("macca","khubar","jeddah airport","fahad king airport","2:30pm","6:30pm", 45 , 1000.0));
             int choose;   
           do{     
Scanner in=new Scanner(System.in);
       System.out.println("-----------welcome to booking flight tickets-------------");
        System.out.println("1. show available tickets  ");
        System.out.println("2. book a ticket  ");
        System.out.println("3. end the program ");
        System.out.println("choose a number : ");
         choose =in.nextInt();
        
        switch (choose){
            case 1 :
            System.out.println(" available tickets:");
        for (int i = 0; i < tickets.size(); i++) {
            System.out.println((i + 1) + ". " + tickets.get(i).getdepartureCountry() + " -> " 
                               + tickets.get(i).getDestinationCountry() +" from airport : "+tickets.get(i).getDepartureAirport()+" to Airport : "+tickets.get(i).getarrivalAirport()+"  time : "+tickets.get(i).getdeparturetime()+"->"+tickets.get(i).getarrivaltime()+" price: "+tickets.get(i).getprice()+" SAR");
                              
        }
            
        break;

            case 2 :
        System.out.println("Enter number of ticket you want to book : ");
        int num =in.nextInt();
        
        switch(num){
            case 1: tickets.get(0).displayFlightDetails();
            
            break;
            case 2: tickets.get(1).displayFlightDetails();
            break;
            case 3: tickets.get(2).displayFlightDetails();
            break;
            case 4: tickets.get(3).displayFlightDetails();
            break;
            case 5: tickets.get(4).displayFlightDetails();
            break;
            case 6: tickets.get(5).displayFlightDetails();
            break;
            case 7: tickets.get(6).displayFlightDetails();
            break;
            case 8: tickets.get(7).displayFlightDetails();
            break;
            case 9: tickets.get(8).displayFlightDetails();
            break;
            case 10: tickets.get(9).displayFlightDetails();
            break;
            default: System.out.println("sorry , invalid");
            }
       
                break;
                
            case 3 :
                System.out.println("end the program");
                break;
        } }while(choose!=2);
     
   }
    


    //ميثود ريم لكلاس hootelBooking
    public static void displayHootelBooking(){
        HotelBooking booking = new HotelBooking();
 int cityChoice;
do{
    cityChoice = booking.displaycities(); 
    switch(cityChoice){  
       
        case 1: booking.displayUlaHootels();booking.reservatioDetails();displayReservatioDetails(booking);break;
        case 2: booking.displayRiyadhHootels();booking.reservatioDetails();displayReservatioDetails(booking);break;
        case 3: booking.displayMecca();booking.reservatioDetails();displayReservatioDetails(booking);break;
        case 4: booking.displayAbha();booking.reservatioDetails();displayReservatioDetails(booking);break;
        case 5: booking.displayKhobar();booking.reservatioDetails();displayReservatioDetails(booking);break;
        case 6: System.out.println("good bye");break;
        default: System.out.println("invalid input! try again.");break;
        
    }}while(cityChoice>6 || cityChoice<1);
    }
     //ميثود في الببلك كلاس تحت المين لريم
    public static void displayReservatioDetails(HotelBooking booking){
        
    System.out.println("Room Type: " + booking.getRoomType());
    System.out.println("Number of Guests: " + booking.getNumberOfGuests());
    if (booking.getBreakfastNeed())
    System.out.println("Breakfast: Included");
else
    System.out.println("Breakfast: Not Included");
    
    System.out.println("Check-in Date: " + booking.getCheckIn());
    System.out.println("Check-out Date: " + booking.getCheckOut());
if (booking.getPpaymentMethod() == 1) {
    System.out.println("The total price of " + booking.getTotalPrice() + " riyal has been paid in full.");
}
   else if (booking.getPpaymentMethod() == 2) 
        System.out.println("Remaining Balance to Pay in Cash upon Arrival: " + (booking.getTotalPrice() - booking.getDeposit())+" riyal");
    }
    
    //ميثود المطعم منيرة 
public static void suggestRestaurants(String city) {
    ArrayList<Restaurant> restaurants = new ArrayList<>();
    restaurants.add(new Restaurant("Riyadh", "MAMO", "Italian", 250.0));
    restaurants.add(new Restaurant("Mecca", "Shrimp Nation", "Seafood", 100.0));
    restaurants.add(new Restaurant("Dammam", "Bait Misk", "Middle Eastern", 150.0));
    restaurants.add(new Restaurant("Abha", "Tonir", "Armenian", 200.0));
    restaurants.add(new Restaurant("Alula", "Somewhere", "Arabic", 300.0));

    System.out.println("Here are restaurant suggestions in " + city + ":");
    boolean found = false;

    for (Restaurant restaurant : restaurants) {
        if (restaurant.city.equalsIgnoreCase(city)) {
            restaurant.displayInfo(); 
            found = true;
        }
    }
    if (!found) {
        System.out.println("Sorry, the city you entered isn't from the available options.");
    }
}

//ميثود اثير لكلاس اوبر
 
    public static void Trip() {
        Scanner input = new Scanner(System.in);

        System.out.println("Enter Hotel Name: ");
        String hotelName = input.nextLine();

        System.out.println("Choose the Type of car (regular or luxury): ");
        String carType = input.nextLine();

       
        Uber trip = new Uber(hotelName, carType);

     
        trip.tripDetails();
    }
//ميثود منيرة للوكيشن
    public static void test(){
        Scanner scanner = new Scanner(System.in);

        System.out.println("Let's find a suitable city for you to travel to.");
        System.out.print("Please enter your budget (1500, 2000, 2500, 3000, 3500): ");
        double userBudget = scanner.nextDouble();
        scanner.nextLine(); 
    System.out.print("Please enter your preferred weather (Hot/Humid Hot/Dry Hot/Cool/Warm): ");
    String userWeather = scanner.nextLine();

        Location suggestedLocation = findLocation(userBudget, userWeather);
         if (suggestedLocation != null) {
            System.out.println("\nWe recommend the following location based on your preferences:");
            suggestedLocation.displayInfo();
        } else {
            System.out.println("\nSorry, we couldn't find a location that matches your preferences.");
        }
    }


    // ميثود عرض معلومات المحلات لنوال
    public static void shopsInfoDis() {
        ArrayList<Shop> shopList = new ArrayList<>();
        shopList.add(new Shop("Al Ula Market", "General", "Al Ula", 4.0));
        shopList.add(new Shop("Kingdom Mall", "Luxury", "Riyadh", 5.8));
        shopList.add(new Shop("Khobar Plaza", "Electronics", "Khobar", 4.0));
        shopList.add(new Shop("Abha Souq", "Traditional", "Abha", 4.5));
        shopList.add(new Shop("Makkah Mall", "Shopping", "Makkah", 5.0));

        System.out.println("Please choose a location:");
        System.out.println("1. Al Ula");
        System.out.println("2. Riyadh");
        System.out.println("3. Khobar");
        System.out.println("4. Abha");
        System.out.println("5. Makkah");
Scanner scanner=new Scanner(System.in);
        int locationChoice = scanner.nextInt();
        String selectedCity = "";

        switch (locationChoice) {
            case 1:
                selectedCity = "Al Ula";
                break;
            case 2:
                selectedCity = "Riyadh";
                break;
            case 3:
                selectedCity = "Khobar";
                break;
            case 4:
                selectedCity = "Abha";
                break;
            case 5:
                selectedCity = "Makkah";
                break;
            default:
                System.out.println("Invalid choice. Exiting.");
                return;
        }

        System.out.println("Shops in " + selectedCity + ":");
        for (Shop shop : shopList) {
            if (shop.getLocation().equals(selectedCity)) {
                System.out.println("Shop Name: " + shop.getShopName());
                System.out.println("Type: " + shop.getShopType());
                System.out.println("Rating: " + shop.getRating());
            }
        }
    }

    // ميثود عرض معلومات الطوارئ لنوال
    public static void emergencyDis() {
        ArrayList<EmergencyInfo> emergencyList = new ArrayList<>();
        emergencyList.add(new EmergencyInfo("911", "Al Ula General Hospital", "alula_hospital@emergency.sa", "Al Ula"));
        emergencyList.add(new EmergencyInfo("911", "Riyadh Care Hospital", "riyadh_hospital@emergency.sa", "Riyadh"));
        emergencyList.add(new EmergencyInfo("911", "Saad Specialist Hospital", "khobar_hospital@emergency.sa", "Khobar"));
        emergencyList.add(new EmergencyInfo("911", "Asir Central Hospital", "abha_hospital@emergency.sa", "Abha"));
        emergencyList.add(new EmergencyInfo("911", "King Abdullah Medical City", "mecca_hospital@emergency.sa", "Makkah"));

        System.out.println("Please choose a location:");
        System.out.println("1. Al Ula");
        System.out.println("2. Riyadh");
        System.out.println("3. Khobar");
        System.out.println("4. Abha");
        System.out.println("5. Makkah");
Scanner scanner=new Scanner(System.in);
        int locationChoice = scanner.nextInt();
        String selectedCity = "";

        switch (locationChoice) {
            case 1:
                selectedCity = "Al Ula";
                break;
            case 2:
                selectedCity = "Riyadh";
                break;
            case 3:
                selectedCity = "Khobar";
                break;
            case 4:
                selectedCity = "Abha";
                break;
            case 5:
                selectedCity = "Makkah";
                break;
            default:
                System.out.println("Invalid choice. Exiting.");
                return;
        }

        System.out.println("Emergency Info for " + selectedCity + ":");
        for (EmergencyInfo emergency : emergencyList) {
            if (emergency.getEmergencyCity().equals(selectedCity)) {
                System.out.println("Phone: " + emergency.getEmergencyPhone());
                System.out.println("Contact: " + emergency.getEmergencyContact());
                System.out.println("Email: " + emergency.getEmergencyEmail());
            }
        }
    }
}
//كلاس غدير اللوق ان
 class Login {
    private String username;
    private String password;

    // Constructor
    public Login(String username, String password) {
        this.username = username;
        this.password = password;
    }

    // Method to validate login
    public boolean login(String enteredUsername, String enteredPassword) {
        return enteredUsername.equals(this.username) && enteredPassword.equals(this.password);
    }

    // Overridable method to display information
    public String displayInfo() {
        return "Username: " + username;
    }
}

//كلاس غدير البيرث ديت
 class BirthDate extends Login {
    private int day;
    private int month;
    private int year;

    // Constructor
    public BirthDate(String username, String password, int day, int month, int year) {
        super(username, password); // Call Login constructor
        this.day = day;
        this.month = month;
        this.year = year;
    }

    // Override the displayInfo() method to include birth date details
    @Override
    public String displayInfo() {
        return super.displayInfo() + ", Birth Date: " + day + "/" + month + "/" + year;
    }
}
//كلاس غدير ترافل انفو

 class TravelInfo extends BirthDate {
    private String nationality;
    private String contactNumber;
    private String cardNumber;
    private String emailAddress;

    // Constructor
    public TravelInfo(String username, String password, int day, int month, int year) {
        super(username, password, day, month, year); // Call BirthDate constructor
    }

    // Method to collect travel info
    public void collectTravelInfo(Scanner scanner) {
        System.out.print("Enter your nationality: ");
        this.nationality = scanner.nextLine();

        System.out.print("Enter your contact number: ");
        this.contactNumber = scanner.nextLine();

        System.out.print("Enter your travel card number: ");
        this.cardNumber = scanner.nextLine();

        System.out.print("Enter your email address: ");
        this.emailAddress = scanner.nextLine();
    }

    // Override the displayInfo() method to include travel details
    @Override
    public String displayInfo() {
        return super.displayInfo() +
                ", Nationality: " + nationality +
                ", Contact Number: " + contactNumber +
                ", Travel Card: " + cardNumber +
                ", Email Address: " + emailAddress;
    }
}


// كلاس ميزانية ، اثير
 class Budget  {
    
    private HotelBooking hotelBooking;
    private Uber uber;
    private flightBooking flightBooking;

    public Budget(HotelBooking hotelBooking, Uber uber, flightBooking flightBooking) {
        this.hotelBooking = hotelBooking;
        this.uber = uber;
        this.flightBooking = flightBooking;
    }

    public void calculateTotalCost() {
        double hotelCost = hotelBooking.getTotalPrice();
        double uberCost = uber.calculateTripCost();
        double flightCost = flightBooking.getprice();

        double totalCost = hotelCost + uberCost + flightCost;

        System.out.println("\n ---- BUDGET ---- ");
        System.out.println("Hotel Cost : " + hotelCost + " SAR");
        System.out.println("Uber Cost : " + uberCost + " SAR");
        System.out.println("Flight Cost : " + flightCost + " SAR");
        System.out.println("\n Total Budget : " + totalCost + " SAR");
    }
}
//كلاس ياسمين 

class flightBooking  {
    private String departureCountry;
    private String destinationCountry;
    private String departureAirport;
    private String arrivalAirport;
    private String departuretime;
    private String arrivaltime;
    private int numOfseat;
    private double ticketPrice;
    
    public flightBooking(){}
    
    public flightBooking(String departureCountry,String destinationCountry,String departureAirport,String arrivalAirport,String departuretime,String arrivaltime, 
            int numOfseat,double ticketPrice){
    this.departureCountry=departureCountry;
    this.destinationCountry=destinationCountry;
    this.departureAirport=departureAirport;
    this.arrivalAirport=arrivalAirport;
    this.departuretime=departuretime;
    this.arrivaltime=arrivaltime;
    this.numOfseat=numOfseat;
    this.ticketPrice=ticketPrice;
     
    }
   
    public void displayFlightDetails(){
        System.out.println("--------------------------your ticket-----------------------------");
        

        System.out.println("from : "+departureCountry+" -> to : "+destinationCountry);
        System.out.println("from Airport : "+departureAirport+" -> to Airport : "+arrivalAirport);
        System.out.println("time: "+departuretime+" to "+arrivaltime);
        System.out.println("available seats : "+numOfseat);
        System.out.println("the price : "+ticketPrice+"SAR");
        System.out.println("-------------------------------------------------------------------");
    }
    
    
    
      //geteers
    public String getdepartureCountry(){
        return departureCountry;
    }
   public String getDestinationCountry(){
        return destinationCountry;
    }
   
   public String getDepartureAirport(){
        return departureAirport;
    }
   public String getarrivalAirport(){
        return arrivalAirport;
    }
   public String getarrivaltime(){
        return arrivaltime;
    }
   public String getdeparturetime(){
        return departuretime;
    }
   public int getnumOfseat(){
        return numOfseat;
    }
   public double getprice(){
        return ticketPrice;
   }  


}
//كلاس ريم
 class HotelBooking{
     
     Scanner input= new Scanner(System.in);

    private  double totalPrice;
    private int numberOfDays;
    private int numberOfGuests;
    private int roomType;
    private Date checkIn;
    private Date checkOut;
    private boolean breakfastNeed;
    private int paymentMethod=0;
    private double deposit=0;
    
   
    public double getTotalPrice(){                      
        return totalPrice;
    }
    public int getNumberOfDays(){
        return numberOfDays;
    }
    public int getNumberOfGuests(){
        return numberOfGuests;
    }
    public String getRoomType(){
        String roomTypeToString=null;
        if(roomType==1)
           roomTypeToString="Single";
        else if(roomType==2)
            roomTypeToString="Double";
        else if(roomType==3)
            roomTypeToString="Suite";
        return roomTypeToString;
    }
    public Date getCheckIn(){
        return checkIn;
    }
      public Date getCheckOut(){
        return checkOut;
    }
    public boolean getBreakfastNeed(){
        return breakfastNeed;
    }
      public double getDeposit(){
        return deposit;
    }
    public double getPpaymentMethod(){
        return paymentMethod;
    }
    

    public int displaycities(){
    String menuOfCities="choose a city of these: \n"
            + "1-Al-Ula city\n"
            + "2-Riyadh\n"
            + "3-Mecca\n"
            + "4-Abha\n"
            + "5-Khobar\n"
            + "6-Exit\n"
            + "Your Choice: ";

   System.out.println("---------------Welcome to the Hotel Booking Service!---------------");
    System.out.println(menuOfCities);
         int cityChoice = input.nextInt();
         return cityChoice;
    }

//    عرض الفنادق
    public void displayUlaHootels(){

 String[] al_UlaHootels = new String[5];

        al_UlaHootels[0] = "Banyan Tree AlUla";
        al_UlaHootels[1]="Shaden Resort";
        al_UlaHootels[2]="Al Shihanah Hotel";
        al_UlaHootels[3]="Habitas AlUla";
        al_UlaHootels[4]="Caravan by Habitas AlUla";

         String menuOfUlaHootels="chhose a hotel of these: \n"
            + "1-Banyan Tree AlUla\n"
            + "2-Shaden Resort\n"
            + "3-Al Shihanah Hotel\n"
            + "4-Habitas AlUla\n"
            + "5-Caravan by Habitas AlUla\n"    
            + "Your Choice: ";

         System.out.println(menuOfUlaHootels);
          int ulaHootel=input.nextInt();
    }

    public void displayRiyadhHootels(){
        String[] riyadhHootels=new String[7];

        riyadhHootels[0]="Four Seasons Hotel Riyadh";
        riyadhHootels[1]="The Ritz-Carlton, Riyadh";
        riyadhHootels[2]="Narcissus Hotel & Spa";
        riyadhHootels[3]="Al Faisaliah Hotel";
        riyadhHootels[4]="Hyatt Regency Riyadh Olaya";
        riyadhHootels[5]="Crowne Plaza Riyadh Minhal";
        riyadhHootels[6]="Shaza Riyadh Hotel";

        String menuOfRiyadhHHootels="chhose a hotel of these: \n"
            + "1-Four Seasons Hotel Riyadh\n"
            + "2-The Ritz-Carlton, Riyadh\n"
            + "3-Narcissus Hotel & Spa\n"
            + "4-Al Faisaliah Hotel\n"
            + "5-Hyatt Regency Riyadh Olaya\n"
            + "6-Crowne Plaza Riyadh Minhal\n"
            + "7-Shaza Riyadh Hotel\n"
            + "Your Choice: ";

        System.out.println(menuOfRiyadhHHootels);
         int riyadhHHootel=input.nextInt();
    }
  public void displayMecca(){
         String[] MeccaHootels=new String[7];

         MeccaHootels[0]="Raffles Makkah Palace";
         MeccaHootels[1]="Makkah Clock Royal Tower, Fairmont";
         MeccaHootels[2]="Park Inn by Radisson Makkah Al Naseem";
         MeccaHootels[3]="Makarem Umm Al Qura Hotel";
         MeccaHootels[4]="Bright Hotel";
         MeccaHootels[5]="Al Shuhada Hotel";
         MeccaHootels[6]="Jabal Omar Address Makkah";

         String menuOfMeccaHootels="chhose a hotel of these: \n"
            + "1-Raffles Makkah Palace\n"
            + "2-Makkah Clock Royal Tower, Fairmont\n"
            + "3-Park Inn by Radisson Makkah Al Naseem\n"
            + "4-Makarem Umm Al Qura Hotel\n"
            + "5-Bright Hotel\n"
            + "6-Al Shuhada Hotel\n"
            + "7-Jabal Omar Address Makkah\n"
            + "Your Choice: ";

         System.out.println(menuOfMeccaHootels);
         int MeccaHootel=input.nextInt();
  }
    public void displayAbha(){
         String[] abhahHootels=new String[6];

        abhahHootels[0]="Abha Palace Hotel";
        abhahHootels[1]="Shada Hotel Abha";
        abhahHootels[2]="Novotel Abha";
        abhahHootels[3]="InterContinental Abha";
        abhahHootels[4]="Mercure Abha";
        abhahHootels[5]="Mercure Abha";

        String menuOfAbhaHHootels="chhose a hotel of these: \n"
            + "1-Abha Palace Hotel\n"
            + "2-Shada Hotel Abha\n"
            + "3-Novotel Abha\n"
            + "4-InterContinental Abha\n"
            + "5-Mercure Abha\n"
            + "Your Choice: ";

         System.out.println(menuOfAbhaHHootels);
         int abhaHHootel=input.nextInt();
    }

    public void displayKhobar(){
        String[] khobarHootels=new String[7];

        khobarHootels[0]="InterContinental Al Khobar";
        khobarHootels[1]="Mövenpick Hotel Al Khobar";
        khobarHootels[2]="Radisson Blu Resort, Al Khobar";
        khobarHootels[3]="Sheraton Dhahran Hotel";
        khobarHootels[4]="Golden Tulip Al Khobar";
        khobarHootels[5]="Novotel Dhahran";
        khobarHootels[6]="Coral Al Khobar Hotel";

        String menuOfKhobarHootels="chhose a hotel of these: \n"
            + "1-InterContinental Al Khobar\n"
            + "2-Mövenpick Hotel Al Khobar\n"
            + "3-Radisson Blu Resort, Al Khobar\n"
            + "4-Sheraton Dhahran Hotel\n"
            + "5-Golden Tulip Al Khobar\n"
            + "6-Novotel Dhahran\n"
            + "7-Coral Al Khobar Hotel\n"
            + "Your Choice: ";

        System.out.println(menuOfKhobarHootels);
         int khobarHootel=input.nextInt();
    }
  

//    التفاصيل
    public void reservatioDetails(){
        
         double pricePerNight= 0;
         double breakfastPriceForPersonPerDay=0;

System.out.println("How many days will you be staying?");
        numberOfDays=input.nextInt();
        
DateFormat sdf=new SimpleDateFormat ("yyyy-MM-dd");
sdf.setLenient(false);
        System.out.println("What time would you like to check in and check out?");
      do {
    System.out.print("Enter check-in date (yyyy-MM-dd): ");
    try {
        checkIn = sdf.parse(input.next());
        
        System.out.print("Enter check-out date (yyyy-MM-dd): ");
        checkOut = sdf.parse(input.next());
        break; // إذا كانت التواريخ صحيحة
    } catch (ParseException e) {
        System.out.println("Invalid date format. Please try again.");
    }
} while (true);


        System.out.println("How many people will be staying?");
        numberOfGuests=input.nextInt();

        boolean validationOfRoomType;
       do{
        System.out.println("What type of room would you prefer?\n1-Single\n2-Double\n3-Suite");
       roomType = input.nextInt();

       if(numberOfGuests>=2 && roomType==1){
           validationOfRoomType=false;
       System.out.println("A Single room cannot accommodate 2 guests or more. Please choose another room type.");}
       else if(numberOfGuests>=3 && roomType==2){
                      validationOfRoomType=false;
           System.out.println("A Double room cannot accommodate 3 guests or more. Please choose another room type.");}
       else if(roomType>3 || roomType<=0){
           validationOfRoomType=false; 
           System.out.println("invalid input! try again.");}
       else{
       validationOfRoomType = true;}

       }while(!validationOfRoomType);

       if(roomType==1){
           pricePerNight=150;
       }
       else if(roomType==2){
           pricePerNight=300;
       }
        else if(roomType==3){
           pricePerNight=500;
       }

        System.out.println("Do you need any additional services like breakfast? Yes/No");
        String breakfastStatus=input.next();  
        if(breakfastStatus.equals("yes") || breakfastStatus.equals("Yes")){
            breakfastNeed=true;
            breakfastPriceForPersonPerDay=20;
        }
        else
            breakfastNeed=false;

//        السعر
//السعر الإجمالي=(سعر الليلة الأساسية لنوع الغرفة+(سعر الفطور لكل شخص×عدد الأشخاص))×عدد الأيام
totalPrice=(pricePerNight+(breakfastPriceForPersonPerDay*numberOfGuests))*numberOfDays;
      System.out.println("Total price is: "+totalPrice+" riyal");
      
System.out.println("Are you okay with the price, and would you like to confirm the reservation? Yes/No");
String guestConfirm=input.next();
if(guestConfirm.equals("NO")||guestConfirm.equals("no"))
    System.out.println("Your reservation has been cancelled.");

else if(guestConfirm.equals("Yes") || guestConfirm.equals("yes")){
    do{
System.out.println("Choose your payment method: ");
System.out.println("1. Credit Card");
System.out.println("2. Cash on Arrival");
 paymentMethod = input.nextInt();

    }while(paymentMethod!=1 && paymentMethod!=2);

if (paymentMethod == 2) {
     deposit = totalPrice * 0.20; // التأمين: 20% من السعر الإجمالي
    System.out.println("You have chosen to pay in cash upon arrival.");
    System.out.println("You must pay a deposit of " + deposit + " to confirm your reservation.");
}

boolean payment=false;
while(!payment){
    System.out.println("Please enter your payment details correctly:");
    System.out.println("Card Number:");
    String cardNumber = input.next();
    
    System.out.println("Expiration Date (MM-YY):");
    String expirationDate = input.next();
    
    System.out.println("CVV:");
    String cvv = input.next();
    if(paymentMethod == 1){
    if (cardNumber.length() == 16 && cvv.length() == 3) {
        System.out.println("Processing payment of " + totalPrice + "...");
         payment= true;
         System.out.println("Payment successful! Your reservation is confirmed.");}}
    else if (paymentMethod == 2){
    if (cardNumber.length() == 16 && cvv.length() == 3) {
        System.out.println("Processing payment of " + deposit + "...");
         payment= true;
    System.out.println("Payment successful! Your reservation is confirmed.");}
}}

}
    } //finish <3.
}
//كلاس المطعم منيرة 
 class Restaurant {
   
    String city;              
    private String restaurantName;    
    private String cuisine;          
    private double budget;           
    
    public Restaurant(String city, String restaurantName, String cuisine, double budget) {
        this.city = city;
        this.restaurantName = restaurantName;
        this.cuisine = cuisine;
        this.budget = budget;
    }
    public void displayInfo() {
     System.out.println("Restaurant: " + restaurantName);
       System.out.println("Cuisine: " + cuisine);
      System.out.println("Budget: " + budget + " SAR");
      System.out.println("Located in: " + city);
      System.out.println("-----------------------------------");
    }   
     public static void suggestRestaurants(String city) {
         ArrayList<Restaurant> restaurants = new ArrayList<>();

         restaurants.add(new Restaurant("Riyadh", "MAMO", "Italian", 250.0));
        restaurants.add(new Restaurant("Mecca", "Shrimp Nation", "Seafood", 100.0));
        restaurants.add(new Restaurant("Dammam", "Bait Misk", "Middle Eastern", 150.0));
        restaurants.add(new Restaurant("Abha", "Tonir", "Armenian", 200.0));
        restaurants.add(new Restaurant("Alula", "Somewhere", "Arabic", 300.0));

         System.out.println("Here are restaurant suggestions in " + city + ":");
        boolean found = false;    
         for (Restaurant restaurant : restaurants) {
            if (restaurant.city.equalsIgnoreCase(city)) {
                restaurant.displayInfo();   
                found = true; }
        }
         if (!found) {
            System.out.println("Sorry, the city you entered isn't from the available options.");
        }
    }
 }
//>
//كلاس اوبر ، اثير
class Uber {
    Uber(){}
    private String hotelName;
    private String carType;
    private double dFromAirport;
    private static final double REGULAR_CAR = 6.0;
    private static final double LUXURY_CAR = 12.0;

    

    public Uber(String hotelName, String carType) {
        this.hotelName = hotelName;
        this.carType = carType;
        this.dFromAirport = dFromAirport(hotelName);
    }

  
    private double dFromAirport(String hotelName) {
        switch (hotelName.toLowerCase()) {
            case "banyan tree alula":
            case "shaden resort":
            case "Al shihanah hotel": 
            case "Habitas Alula": 
            case"caravan by habitas":    
                return 49.0;

            case "four seasons hotel":
            case "the titz-carlton":    
            case "narcissus hotel and spa":
            case "al faisaliah hotel":    
                return 35.0;

             case "hyatt regency riyadh":
                return 46.0;


            case"crowne plaza riyadh " :  
                    return 49.0;
                    
            case"shaza riyadh hotel":
                    return 35.0;

            case "intercontinental alkhobar":
            case"novotel dhahran":  
            case"coral alkhobar":    
                return 47.0;
                
            case "movenpick hotel alkhobar":
            case"radisson blu resort": 
            case"sheraton Dhahran": 
            case"golden tulip":
                return 43.0;
                
            case "abha palace hotel":
             case"novotel abha":
            case"intercontinental abha":    
                return 26.0;

            case "shada hotel abha":
             case"mercure abha":    
                return 11.0;

            case "raffles makkah palace":
            case"park in by radisson makkah":
            case"makkah um al qura":  
            case"pright hotel":    
                return 94.0;

            case "makkah clock royal tower al nassem":
            case"al shada hotel":
            case"jabal omar address makkah":     
                return 89.0;

            default:
                System.out.println("The Hotel is not known.");
                return 0.0;
        }
    }

  
    public double calculateTripCost() {
    double pricePerKilo;

    if (carType.equalsIgnoreCase("luxury")) {
        pricePerKilo = LUXURY_CAR;
    } else if (carType.equalsIgnoreCase("regular")) {
        pricePerKilo = REGULAR_CAR;
    } else {
        System.out.println("Car Type Not Available");
        return 0.0;  
    }
    return dFromAirport * pricePerKilo;
}

   
    public String getHotelName() {
        return hotelName;
    }

    public String getCarType() {
        return carType;
    }

    public double getDFromAirport() {
        return dFromAirport;
    }

    public double getTripCost() {
        return calculateTripCost();
    }

   
    public void tripDetails() {
        System.out.println("\n---- TRIP DETAILS ----");
        System.out.println("Hotel Name: " + getHotelName());
        System.out.println("Car Type: " + getCarType());
        System.out.println("Distance from airport to hotel: " + getDFromAirport() + " km");
        System.out.println("Total Cost: " + getTripCost() + " SAR ");
    }
}
//كلاس لوكيشن منيرة
 class Location {
    private String city;
    private String weather;
    private double budget;

 
    public Location(String city, String weather, double budget) {
        this.city = city;
        this.weather = weather;
        this.budget = budget;
     }
     public String getCity() {
        return city;}
        
     public void setWeather(String weather) {
        this.weather = weather;
     }
     private String getWeather(){
         return weather ;
     }
     public void setBudget(double budget) {
        this.budget = budget;
     }
     private double getBudget(){
         return budget ;
     }
     public void displayInfo() {
        System.out.println("City: " + city);
        System.out.println("W2eather: " + weather);
        System.out.println("Budget: " + budget + " SAR");
    }
     public static Location findLocation(double userBudget, String userWeather) {
         Location dammam = new Location("Dammam", "Humid Hot", 1500);
        Location abha = new Location("Abha", "Cool", 3000);
        Location alula = new Location("Alula", "Warm", 3500);
        Location mecca = new Location("Mecca", "Hot", 2000);
        Location riyadh = new Location("Riyadh", "Dry Hot", 2500);

         if (userBudget >= dammam.getBudget() && dammam.getWeather().equalsIgnoreCase(userWeather)) {
            return dammam;
        } else if (userBudget >= abha.getBudget() && abha.getWeather().equalsIgnoreCase(userWeather)) {
            return abha;
        } else if (userBudget >= alula.getBudget() && alula.getWeather().equalsIgnoreCase(userWeather)) {
            return alula;
        } else if (userBudget >= mecca.getBudget() && mecca.getWeather().equalsIgnoreCase(userWeather)) {
            return mecca;
        } else if (userBudget >= riyadh.getBudget() && riyadh.getWeather().equalsIgnoreCase(userWeather)) {
            return riyadh; }
        return null;} }

// كلاس المحلات لنوال
class Shop {
    private String shopName;
    private String shopType;
    private String location;
    private double rating;

    public Shop(String name, String type, String location, double rating) {
        this.shopName = name;
        this.shopType = type;
        this.location = location;
        this.rating = rating;
    }

    public String getShopName() {
        return shopName;
    }

    public String getShopType() {
        return shopType;
    }

    public String getLocation() {
        return location;
    }

    public double getRating() {
        return rating;
    }
}
// كلاس معلومات الطوارئ لنوال
class EmergencyInfo {
    private String emergencyPhone;
    private String emergencyContact;
    private String emergencyEmail;
    private String city;

    public EmergencyInfo(String phone, String contact, String email, String city) {
        this.emergencyPhone = phone;
        this.emergencyContact = contact;
        this.emergencyEmail = email;
        this.city = city;
    }

    public String getEmergencyPhone() {
        return emergencyPhone;
    }

    public String getEmergencyContact() {
        return emergencyContact;
    }

    public String getEmergencyEmail() {
        return emergencyEmail;
    }

    public String getEmergencyCity() {
        return city;
    }
}
//Group 4>
